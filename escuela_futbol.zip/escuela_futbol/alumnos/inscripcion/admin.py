
from django.contrib import admin
from .models import Alumno


@admin.register(Alumno)
class AlumnoAdmin(admin.ModelAdmin):
    list_display = (
        'nombres',
        'apellidos',
        'documento',
        'categoria',
        'telefono',
        'nombre_acudiente',
    )

    search_fields = (
        'nombres',
        'apellidos',
        'documento',
        'nombre_acudiente',
    )

    list_filter = ('categoria',)

    ordering = ('apellidos', 'nombres')

