
from django import forms
from .models import Alumno


class AlumnoForm(forms.ModelForm):
    class Meta:
        model = Alumno
        fields = [
            'nombres',
            'apellidos',
            'documento',
            'fecha_nacimiento',
            'telefono',
            'categoria',
            'nombre_acudiente',
            'telefono_acudiente',
        ]

        widgets = {
            'fecha_nacimiento': forms.DateInput(
                attrs={'type': 'date'}
            ),
        }

        labels = {
            'nombres': 'Nombres del alumno',
            'apellidos': 'Apellidos del alumno',
            'documento': 'Número de documento',
            'fecha_nacimiento': 'Fecha de nacimiento',
            'telefono': 'Teléfono del alumno',
            'categoria': 'Categoría deportiva',
            'nombre_acudiente': 'Nombre del acudiente',
            'telefono_acudiente': 'Teléfono del acudiente',
        }
