
from django.db import models


class Alumno(models.Model):
    CATEGORIAS = [
        ('SUB-8', 'Sub-8'),
        ('SUB-10', 'Sub-10'),
        ('SUB-12', 'Sub-12'),
        ('SUB-15', 'Sub-15'),
        ('SUB-17', 'Sub-17'),
        ('LIBRE', 'Libre'),
    ]

    nombres = models.CharField(max_length=60)
    apellidos = models.CharField(max_length=60)
    documento = models.CharField(max_length=20, unique=True)
    fecha_nacimiento = models.DateField()
    telefono = models.CharField(max_length=20)
    categoria = models.CharField(
        max_length=10,
        choices=CATEGORIAS
    )
    nombre_acudiente = models.CharField(max_length=120)
    telefono_acudiente = models.CharField(max_length=20)

    fecha_inscripcion = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.nombres} {self.apellidos}"
