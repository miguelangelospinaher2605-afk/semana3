
from django.test import TestCase
from .models import Alumno


class AlumnoModelTest(TestCase):

    def test_crear_alumno(self):
        alumno = Alumno.objects.create(
            nombres='Juan',
            apellidos='Perez',
            documento='123456789',
            fecha_nacimiento='2010-05-15',
            telefono='3001234567',
            categoria='SUB-15',
            nombre_acudiente='Carlos Perez',
            telefono_acudiente='3007654321'
        )

        self.assertEqual(alumno.nombres, 'Juan')
        self.assertEqual(alumno.apellidos, 'Perez')
        self.assertEqual(str(alumno), 'Juan Perez')

