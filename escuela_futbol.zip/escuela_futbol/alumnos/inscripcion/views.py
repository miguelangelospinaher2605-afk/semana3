
from django.shortcuts import render, redirect
from .forms import AlumnoForm
from .models import Alumno


def inicio(request):
    return render(request, 'inscripcion/index.html')


def registrar_alumno(request):
    if request.method == 'POST':
        form = AlumnoForm(request.POST)

        if form.is_valid():
            form.save()
            return redirect('lista_alumnos')
    else:
        form = AlumnoForm()

    return render(request, 'inscripcion/registrar.html', {
        'form': form
    })


def lista_alumnos(request):
    alumnos = Alumno.objects.all().order_by('-id')
    return render(request, 'inscripcion/lista.html', {
        'alumnos': alumnos
    })

